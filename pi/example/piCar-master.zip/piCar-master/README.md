# My Pi Car
===============================
Author: WangHeng

Blog: http://wangheng.org
#### LISENSE:GPL
===============================
User Guide:


> sudo python server.py 


then visit Pi_IP:2000

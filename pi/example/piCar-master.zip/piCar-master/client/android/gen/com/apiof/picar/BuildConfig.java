/** Automatically generated file. DO NOT MODIFY */
package com.apiof.picar;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}